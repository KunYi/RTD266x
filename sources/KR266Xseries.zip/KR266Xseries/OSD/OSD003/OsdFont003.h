#if(_OSD_TYPE == _OSD003)


extern BYTE code FntGlobal[];


#endif
