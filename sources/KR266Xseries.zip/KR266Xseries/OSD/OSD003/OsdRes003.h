#if(_OSD_TYPE == _OSD003)


extern BYTE code tPALETTE_0[];
extern BYTE code tMainWindowStyle[];
extern BYTE code tNosignalWINDOW[];

extern BYTE code *sTvSystem[];
extern BYTE code *sAutoSearch[];
extern BYTE code *sManualSearch[];
extern BYTE code *sTuning[];
extern BYTE code *sChannel[];
extern WORD code *sTVType[];

extern BYTE code *sContrast[];
extern BYTE code *sBrightness[];
extern BYTE code *sHue[];
extern BYTE code *sSaturation[];
extern BYTE code *sVolume[];
extern BYTE code sSource[];
extern BYTE code sLR[];
extern BYTE code sUD[];
extern BYTE code sDisplayRatio[];	
extern BYTE code *sReset[];
extern BYTE code sExit[];
extern BYTE code *sLanguage[];
extern BYTE code *sLangName[];
extern BYTE code *sAutoADJName[];
extern BYTE code *sFm[];
extern code BYTE sFM_OFF[];
extern code BYTE sFM_A1[];
extern code BYTE sFM_A2[];
extern code BYTE sFM_A3[];
extern code BYTE sFM_A4[];
extern code BYTE sFM_A5[];
extern code BYTE sFM_A6[];
extern code BYTE sFM_A7[];
extern code BYTE sFM_A8[];
extern code BYTE sFM_B1[];
extern code BYTE sFM_B2[];
extern code BYTE sFM_B3[];
extern code BYTE sFM_B4[];
extern code BYTE sFM_B5[];
extern code BYTE sFM_B6[];
extern code BYTE sFM_B7[];
extern code BYTE sFM_B8[];
extern code BYTE sMhz[];

extern BYTE code sAV1[];
extern BYTE code sAV2[];
extern BYTE code sTV[];
extern BYTE code sVGA[];
extern BYTE code sHDMI[];
extern BYTE code sMute[];

extern BYTE code s16_9[];
extern BYTE code s4_3[];
extern BYTE code *sYes[];
extern BYTE code *sNo[];
extern BYTE code sVisatech[];
extern BYTE code sNoSignal[];
extern BYTE code sReseting[];
extern BYTE code *sOff[];
extern BYTE code *sOn[];

extern BYTE code sStandard[];
extern BYTE code sSoft[];
extern BYTE code sVivid[];
extern BYTE code sPersonal[];
#endif		//#if(_OSD_TYPE == _OSD003)
