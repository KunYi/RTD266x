////////////////////////////////////////////////////////////////////////////
//         Copyright of KaiXuang Video Technology Co.,LTD                 //
//                                                                        //
//                                                                        //
//                    For RTD2660/RTD2662 KR266Xseries                    //
////////////////////////////////////////////////////////////////////////////


//--------------------------------------------------
// PCB IO define																				  
//--------------------------------------------------
/*       BL.lin
   _HDMI_SUPPORT->_OFF       Mark   ?CO?HDMI
   _YPBPR_SUPPORT->_OFF      Mark   ?CO?YPBPR
   _VIDEO_TV_SUPPORT->_OFF   Mark   CSHOWTVNUMBER ~ ?PR?OSDPROC003(Only for OSD003)
*/

//--------------------------------------------------

