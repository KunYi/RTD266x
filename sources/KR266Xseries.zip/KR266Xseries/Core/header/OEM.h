/***********************************************
OEM Project define 
wtao 20100412
************************************************/
//**********************START**************************

#define RTD2660_VGA_AV_MP5_DMB    0
#define RTD2660_VGA_AV_MP5             1


//Select one oem type
#define OEM_TYPE        RTD2660_VGA_AV_MP5_DMB// RTD2660_VGA_AV_MP5



//**********************END**************************


