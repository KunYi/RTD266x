#ifndef __SDCC
#include "alien/global_.h"
#include "alien/include_.h"

bit  bTVNoSignal;

BYTE kx_CSearchVideoMode(bit bMode)
{

}
void kx_CInitialVDC(void)
{

}
void kx_CVDCOutputDisable(void)
{

}
bit kx_CVideoModeLocked(void)
{

}
void kx_CSelectVideoChannel(BYTE ucYCrChannel, BYTE ucAVOut)
{

}
void kx_CAdjustVDCHue(const BYTE ucVDCHue)
{

}
bit kx_CVideoModeDetect(void)
{

}
bit kx_CVideoIsChange(void)
{

}
void kx_CWriteTuner(BYTE *Array)
{

}
BYTE kx_CReadIfPllDM(void)
{

}
bit bCheckTuner(BYTE TunerAddr)
{

}
void kx_CSetTVFrameSync(void)
{

}
void CVideoSetVDCSaturation(BYTE ucValue)
{

}
#endif
