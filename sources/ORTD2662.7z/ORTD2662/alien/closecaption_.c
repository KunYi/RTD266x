#ifndef __SDCC
#include "alien/global_.h"
#endif
