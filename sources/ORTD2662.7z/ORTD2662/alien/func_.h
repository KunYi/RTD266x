#include "alien/global_.h"
#ifdef __FUNCC__
#else
#endif


bit bChangeSource(void);
void ChangeSourceHandler(void);
void CInitInputSource(void);
void CInitSoundChannel(BYTE ucChannel);
