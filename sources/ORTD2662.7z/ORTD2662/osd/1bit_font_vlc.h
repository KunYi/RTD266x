#pragma once

#include <stdint.h>

extern const uint8_t font_1bit_vlc[];