#pragma once

#include "core/config_defines.h"

// Screen mirroring (if supported)
#define HOR_MIRRROR TRUE
#define VER_MIRRROR FALSE

// Infrared Remote Control
#define IR_PROTOCOL IR_NEC // Possible values: IR_NEC, IR_RC5