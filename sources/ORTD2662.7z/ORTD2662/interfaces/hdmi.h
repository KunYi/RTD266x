#pragma once
#include <stdint.h>

void InitHDMI(uint8_t tmdsIn);