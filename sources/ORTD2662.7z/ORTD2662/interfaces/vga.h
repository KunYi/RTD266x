#pragma once

void InitVGA(uint8_t videoIn);