#include <stdint.h>

#include <peripherals/adc.h>
