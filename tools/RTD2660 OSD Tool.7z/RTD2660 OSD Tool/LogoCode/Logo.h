#if(_LOGO_ENABLE)

/*
// #Code : Logo Info
*/

typedef struct
{
	BYTE LogoWidth;
	BYTE LogoHeight;
	WORD FontBassAddress;

	BYTE DoubleSize;

	WORD Font1BitOffset;
	WORD Font2BitOffset;
	WORD Font4BitOffset;

	BYTE Font1BitCnt;
	BYTE Font2BitCnt;
	BYTE Font4BitCnt;
	
	BYTE HPositon;
	BYTE VPosition;

	BYTE BackGroundColorR;
	BYTE BackGroundColorG;
	BYTE BackGroundColorB;
	

}SLogoOsdMap;


#ifdef __LOGO__

//-------------------------------------------------------------------------------
// #Code : SLogoOsdMap
//-------------------------------------------------------------------------------
// #Code : Palette
//-------------------------------------------------------------------------------
// #Code : Logo Table
//-------------------------------------------------------------------------------
// #Code : 1 Bit Font
//-------------------------------------------------------------------------------
// #Code : 2 Bit Font
//-------------------------------------------------------------------------------
// #Code : 4 Bit Font
//-------------------------------------------------------------------------------


#else




#endif		//#ifdef __LOGO__


void CDrawLogo(void); 
void SetLogoOsdMap(void);
void COsdFxCodeWrite(BYTE *pArray);
void COsdLogoColorPalette(BYTE *pColorPaletteArray);



#endif		//#if(_LOGO_ENABLE)

extern BYTE code tLogoTemp;
